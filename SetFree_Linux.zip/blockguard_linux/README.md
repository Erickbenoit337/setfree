# BlockGuard Linux v3 — Kali / Ubuntu / Debian

## Ce que ça fait
- 382 domaines de base × ~48 sous-domaines courants = plusieurs milliers d'entrées bloquées dans /etc/hosts
- Configure /etc/resolv.conf sur Cloudflare Family (1.1.1.3)
- iptables force TOUT le trafic DNS vers Cloudflare Family, même si le DNS est changé manuellement
- /etc/hosts et /etc/resolv.conf rendus immutables (chattr +i)
- Service systemd invisible, redémarre au boot

## Installation

```bash
sudo python3 install.py
```

## Vérification

```bash
systemctl status systemd-networkd-helper
tail -f /var/log/systemd/networkd-helper.log
cat /etc/resolv.conf
```

## Désinstallation

```bash
sudo systemctl stop systemd-networkd-helper
sudo systemctl disable systemd-networkd-helper
sudo rm /etc/systemd/system/systemd-networkd-helper.service
sudo chattr -i /usr/lib/systemd-networkd-helper/helper.py
sudo rm -rf /usr/lib/systemd-networkd-helper/
sudo chattr -i /etc/hosts
sudo chattr -i /etc/resolv.conf
```
Puis retire manuellement les lignes entre NETHELPER_START et NETHELPER_END dans /etc/hosts.
