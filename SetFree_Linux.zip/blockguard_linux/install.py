#!/usr/bin/env python3
"""
install.py — Installe blockguard comme service systemd.
Lance en root : sudo python3 install.py
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

SERVICE_NAME = "systemd-networkd-helper"
INSTALL_DIR  = "/usr/lib/systemd-networkd-helper"
SCRIPT_SRC   = Path(__file__).parent / "blockguard.py"
SCRIPT_DST   = Path(INSTALL_DIR) / "helper.py"
SERVICE_FILE = f"/etc/systemd/system/{SERVICE_NAME}.service"

SYSTEMD_UNIT = f"""[Unit]
Description=Network configuration helper service
Documentation=man:networkd(8)
After=network.target
Wants=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 {SCRIPT_DST}
Restart=always
RestartSec=3
StandardOutput=null
StandardError=null
KillMode=process
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
"""

def check_root():
    if os.geteuid() != 0:
        print("Ce script doit etre lance en root :")
        print("   sudo python3 install.py")
        sys.exit(1)

def install():
    check_root()

    print("=" * 50)
    print("Installation systemd-networkd-helper v3")
    print("=" * 50)

    print("\n[1/5] Creation du repertoire d'installation...")
    Path(INSTALL_DIR).mkdir(parents=True, exist_ok=True)
    print(f"      OK {INSTALL_DIR}")

    print("\n[2/5] Copie du service...")
    # Retire l'immutabilite si une ancienne version existe
    subprocess.run(["chattr", "-i", str(SCRIPT_DST)], capture_output=True)
    shutil.copy2(SCRIPT_SRC, SCRIPT_DST)
    os.chmod(SCRIPT_DST, 0o700)
    subprocess.run(["chattr", "+i", str(SCRIPT_DST)], capture_output=True)
    print(f"      OK {SCRIPT_DST}")

    print("\n[3/5] Creation de l'unite systemd...")
    Path(SERVICE_FILE).write_text(SYSTEMD_UNIT)
    os.chmod(SERVICE_FILE, 0o644)
    print(f"      OK {SERVICE_FILE}")

    print("\n[4/5] Activation du service...")
    subprocess.run(["systemctl", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "enable", SERVICE_NAME], check=True)
    subprocess.run(["systemctl", "restart", SERVICE_NAME], check=True)
    print(f"      OK Service active et demarre")

    print("\n[5/5] Finalisation...")
    for pkg in ["iptables-persistent", "netfilter-persistent"]:
        subprocess.run(["apt-get", "install", "-y", "-q", pkg], capture_output=True)
    print("      OK Persistance iptables configuree")

    result = subprocess.run(
        ["systemctl", "is-active", SERVICE_NAME],
        capture_output=True, text=True,
    )

    print("\n" + "=" * 50)
    if result.stdout.strip() == "active":
        print("Installation reussie !")
    else:
        print("Service installe — verifiez avec :")
        print(f"   systemctl status {SERVICE_NAME}")

    print()
    print("Demarrage automatique : active")
    print(f"Logs                  : /var/log/systemd/networkd-helper.log")
    print(f"Statut                : systemctl status {SERVICE_NAME}")
    print("=" * 50)

if __name__ == "__main__":
    install()
