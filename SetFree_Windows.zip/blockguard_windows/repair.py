"""
REPARATION D'URGENCE — Windows
Supprime tout ce qu'a fait BlockGuard et restaure Windows à la normale.
Lancer en PowerShell Administrateur : python repair.py
"""

import subprocess
import sys
import ctypes
import winreg
from pathlib import Path

HOSTS_FILE   = r"C:\Windows\System32\drivers\etc\hosts"
HOSTS_MARKER = "# WND_FILTER_START"
HOSTS_END    = "# WND_FILTER_END"

def is_admin():
    try: return ctypes.windll.shell32.IsUserAnAdmin()
    except: return False

def repair():
    if not is_admin():
        print("❌ Lance ce script en Administrateur (clic droit PowerShell → Admin)")
        sys.exit(1)

    print("=== RÉPARATION BLOCKGUARD WINDOWS ===\n")

    # 1. Arrêt et suppression du service
    print("[1] Arrêt du service...")
    subprocess.run(["sc", "stop", "WinNetDiagHost"],   capture_output=True)
    subprocess.run(["sc", "delete", "WinNetDiagHost"], capture_output=True)
    # Essai via pywin32 si installé
    try:
        import win32serviceutil
        try: win32serviceutil.StopService("WinNetDiagHost")
        except: pass
        try: win32serviceutil.RemoveService("WinNetDiagHost")
        except: pass
    except ImportError:
        pass
    print("    ✓ Service supprimé")

    # 2. Restauration du fichier hosts
    print("[2] Restauration du fichier hosts...")
    subprocess.run(["attrib", "-R", "-S", "-H", HOSTS_FILE], capture_output=True)
    try:
        content = Path(HOSTS_FILE).read_text(encoding="utf-8", errors="ignore")
        if HOSTS_MARKER in content and HOSTS_END in content:
            start   = content.index(HOSTS_MARKER)
            end     = content.index(HOSTS_END) + len(HOSTS_END)
            content = content[:start].rstrip() + "\n"
            Path(HOSTS_FILE).write_text(content, encoding="utf-8")
            print("    ✓ Bloc de blocage supprimé du fichier hosts")
        else:
            print("    ✓ Fichier hosts déjà propre")
    except Exception as e:
        print(f"    ⚠ Erreur hosts: {e}")
        print(f"    → Ouvre {HOSTS_FILE} manuellement et supprime les lignes entre")
        print(f"      {HOSTS_MARKER} et {HOSTS_END}")

    # 3. Restauration du DNS (remet "automatique" sur tous les adaptateurs)
    print("[3] Restauration du DNS automatique...")
    try:
        # Via netsh — remet le DNS en automatique (DHCP) sur toutes les interfaces
        result = subprocess.run(
            ["netsh", "interface", "show", "interface"],
            capture_output=True, text=True
        )
        for line in result.stdout.splitlines():
            if "Connected" in line or "Connecté" in line:
                parts = line.split()
                if len(parts) >= 4:
                    iface = " ".join(parts[3:])
                    subprocess.run(
                        ["netsh", "interface", "ip", "set", "dns",
                         f"name={iface}", "source=dhcp"],
                        capture_output=True
                    )
        print("    ✓ DNS remis en automatique (DHCP)")
    except Exception as e:
        print(f"    ⚠ {e}")

    # Restauration via registre aussi
    try:
        key_path = r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0, winreg.KEY_SET_VALUE)
        try: winreg.DeleteValue(key, "NameServer")
        except: pass
        winreg.CloseKey(key)
    except Exception:
        pass

    # 4. Suppression du verrou DNS (NC_AddRemoveComponents)
    print("[4] Suppression des restrictions réseau...")
    try:
        key_path = r"SOFTWARE\Policies\Microsoft\Windows\NetworkConnections"
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0, winreg.KEY_SET_VALUE)
        try: winreg.DeleteValue(key, "NC_AddRemoveComponents")
        except: pass
        winreg.CloseKey(key)
        print("    ✓ Restrictions réseau supprimées")
    except Exception:
        print("    ✓ Pas de restrictions à supprimer")

    # 5. Suppression des politiques Edge
    print("[5] Suppression des politiques Edge...")
    try:
        key_path = r"SOFTWARE\Policies\Microsoft\Edge"
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0, winreg.KEY_SET_VALUE)
        for val in ["DnsOverHttpsMode", "DnsOverHttpsTemplates"]:
            try: winreg.DeleteValue(key, val)
            except: pass
        winreg.CloseKey(key)
        print("    ✓ Politiques Edge supprimées")
    except Exception:
        print("    ✓ Pas de politiques Edge à supprimer")

    # 6. Vide le cache DNS
    print("[6] Nettoyage du cache DNS...")
    subprocess.run(["ipconfig", "/flushdns"], capture_output=True)
    subprocess.run(["ipconfig", "/release"],  capture_output=True)
    subprocess.run(["ipconfig", "/renew"],    capture_output=True)
    print("    ✓ Cache DNS vidé")

    print("\n" + "="*40)
    print("✅ Windows restauré à la normale !")
    print()
    print("Redémarre ton PC pour être sûr que")
    print("tout est bien rétabli.")
    print("="*40)

if __name__ == "__main__":
    repair()
