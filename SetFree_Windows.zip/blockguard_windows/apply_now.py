"""
apply_now.py v3 — Applique immediatement le blocage complet
(382 domaines de base x sous-domaines = plusieurs milliers d'entrees).
Lance en PowerShell Administrateur : python apply_now.py
"""

import subprocess, sys, ctypes, os, winreg
from pathlib import Path

HOSTS_FILE   = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "drivers" / "etc" / "hosts"
HOSTS_MARKER = "# WND_FILTER_START"
HOSTS_END    = "# WND_FILTER_END"

SUBDOMAINS = [
    "www", "fr", "en", "de", "es", "pt", "it", "ru", "nl", "pl",
    "tr", "ar", "ja", "ko", "zh", "hu", "ro", "cs", "sv", "no",
    "da", "fi", "el", "he", "uk", "vi", "th", "id", "ms", "hi",
    "m", "mobile", "cdn", "static", "img", "media", "api", "rt",
    "thumbs", "thumb", "i", "v", "dl", "down", "stream", "cams",
]

BLOCKED_DOMAINS = {
    "18.com","18eighteen.com","18onlygirls.com","18videoz.com","1pondo.tv",
    "21sextury.com","3movs.com","4tube.com","9hentai.to","abby-winters.com",
    "abbywinters.com","admireme.vip","adnium.com","adspyglass.com","adult.com",
    "adultadworld.com","adultempire.com","adultfriendfinder.com","adultfriendfinder.net","adultgames.io",
    "adultgamesworld.net","adultsearch.com","adulttime.com","adulttimenetwork.com","adxpansion.com",
    "allgirlmassage.com","allherluv.com","alphaporno.com","amateurallure.com","amourangels.com",
    "analdin.com","analdin.net","analvids.com","anyporn.com","ashemaletube.com",
    "asianpornmovies.com","av01.tv","avgle.com","babepedia.com","babes.com",
    "babesource.com","backroomcastingcouch.com","badmilfs.com","badoinkvr.com","bangbros.com",
    "bangbrosnetwork.com","bangcasting.com","bangedbaby.com","bangyoulater.com","barelylegal.com",
    "bdsmstreak.com","bdsmx.tube","beeg.com","beeg.net","beeg.org",
    "benaughty.com","bigbootywebsite.com","biggercity.com","bimbim.com","bitchesgirls.com",
    "bitchesgirls.net","blacked.com","bongacams.com","bound.com","boyfriendtv.com",
    "brattysis.com","bravoerotica.net","bravotube.net","brazzers.com","brazzers.net",
    "brazzersnetwork.com","bunnyteens.com","cam4.com","cam4.net","cams.com",
    "camsoda.com","camster.com","camwhores.tv","camwhores.video","caribbeancom.com",
    "castingcouchhd.com","castingcouchx.com","casualx.com","chatrandom.com","chaturbate.com",
    "chaturbate.eu","chaturbate.net","chaturbate.org","classicpornfilms.org","clickadu.com",
    "cliphunter.com","clips4sale.com","clips4sale.net","clubdom.com","clubseventeen.com",
    "coeds.com","collegefuckparties.com","collegerules.com","contentabc.com","coomer.party",
    "coomer.su","cumlouder.com","czechcasting.com","czechstreets.com","czechvr.com",
    "daftsex.com","danbooru.donmai.us","deeper.com","devicebondage.com","digitalplayground.com",
    "dirtyroulette.com","divinebitches.com","dmm.co.jp","domai.com","domai.net",
    "dorcelclub.com","dorcelvision.com","drtuber.com","drtuber.net","dungeoncorp.com",
    "e-hentai.org","efukt.com","efukt.net","efukt.org","empflix.com",
    "eporner.com","eporner.net","ero-advertising.com","erogedownload.com","erome.com",
    "erome.net","eros.com","eroticads.com","eroticbeauty.com","eroticmonkey.ch",
    "erotik.com","eroxia.com","errotica-archives.com","escortbabylon.net","eternaldesire.com",
    "eurogirlsescort.com","evil-angel.com","evilangel.com","ex-gf.com","exgfporntube.org",
    "exgirlfriendmarket.com","exhentai.org","exoclick.com","exploitedcollegegirls.com","exposedgfs.org",
    "exxxtrasmall.com","f95zone.to","familyhookups.com","familysinners.com","familystrokes.com",
    "fancentro.com","fansly.com","fapello.com","fapello.to","fapster.com",
    "fapster.xxx","fapvid.com","fc2.com","femjoy.com","fetish.com",
    "fetlife.com","fetlife.net","firstauditions.com","fling.com","flirt4free.com",
    "flirthookup.com","foxxxtail.com","free.xxx","freegrannyvideos.org","freeones.com",
    "freeporn.com","freeporn.hu","freeporn8.org","freepornoxxx.org","freepornvideos.org",
    "freeuse.com","freeuse.net","freeusemilf.com","freewebcamsex.org","frenchcandy.com",
    "freshteenporn.org","fuckingmachines.com","fuckswipe.com","fullhd-porn.com","fullporner.com",
    "fuq.com","fuq.net","fux.com","gaymaletube.com","gelbooru.com",
    "gelbooru.org","gfrevenge.com","gfsexvideos.org","girlfriendsfilms.com","girlfriendvideos.com",
    "girlfriendvideos.org","girlsdoporn.org","girlsdotoys.org","girlsway.com","goddessnudes.com",
    "goldpornfilms.com","goodporn.to","gotporn.com","gotporn.net","grandmaporn.net",
    "grandmaporntube.com","grannycinema.com","gratisporno.org","hanime.tv","hardtied.com",
    "hclips.com","hclips.net","hdporncomics.com","hegre.com","hentai2read.com",
    "hentaicity.com","hentaicloud.com","hentaifox.com","hentaihaven.com","hentaihaven.org",
    "hentaihaven.xxx","hentaimama.io","hentaiporns.org","heyzo.com","hgames.io",
    "hilltopads.net","hitomi.la","hogtied.com","homegrownvideo.com","homemoviestube.com",
    "hornymovies.com","hornywishes.com","hotgoo.com","housewifecrazy.com","hustler.com",
    "imagefap.com","imagefap.net","imagefapfree.org","imlive.com","infernalrestraints.com",
    "insex.com","instabang.com","ixxx.com","jacquieetmicheltv.com","jacquieetmicheltv.net",
    "jasmin.com","jav.guru","javbus.com","javbus.net","javbus.org",
    "javdoe.sh","javhd.com","javhd.net","javlib.com","javmost.com",
    "jizzhut.com","joymii.com","juicyads.com","julesjordan.com","justfor.fans",
    "kanoodle.com","kanoodle.org","karups.com","karupsha.com","karupsow.com",
    "karupspc.com","kasidie.com","keezmovies.com","keezmovies.net","kemono.party",
    "kemono.su","kink.com","kink.org","ladyboy.xxx","lesbea.com",
    "lesbiansex.tv","lesbianx.com","lewdzone.com","lezcuties.com","littlecaprice-dreams.com",
    "littlecaprice.com","livegirls.com","livejasmin.com","livejasmin.net","local-fuck.com",
    "lovehomeporn.com","loyalfans.com","lubed.com","luscious.net","maledom.com",
    "maleslaves.com","manyvids.com","manyvids.net","masturb.com","matureclub.com",
    "matureforlife.org","maturenl.com","maturetube.com","maturetubehere.com","maturewomanvideos.com",
    "maturewomanvideos.org","megapersonals.eu","meninpain.com","met-art.com","metart.com",
    "metartx.com","milfed.com","milfvr.com","milfzr.com","missav.com",
    "missav.net","missav.ws","mixxxer.com","mofos.com","momlesson.com",
    "mommysgirl.com","momsteachsex.com","momxxx.com","morazzia.com","motherless.com",
    "motherless.net","motherless.org","motherlessvideos.org","myex.com","myfamilypies.com",
    "myfreecams.com","myfreecams.net","mylf.com","mylf.network","mylivecam.xxx",
    "myveryfirsttime.com","naughtyamerica.com","naughtyamerica.net","netvideogirls.com","nhentai.com",
    "nhentai.net","noodlemagazine.com","nubilefilms.com","nubiles-porn.com","nubiles.net",
    "nuovoads.com","nutaku.net","nuvid.com","ok.xxx","older-women.com",
    "oldertube.com","oldgrannyporn.org","oldiesporn.org","oldnanny.com","oldpornfun.com",
    "onlyfans.com","onlyfans.net","pacopacomama.com","passion.com","penthouse.com",
    "petitehdporn.com","playvids.com","plugrush.com","popads.net","popcash.net",
    "porn.com","porn.xxx","porn300.com","pornbraze.com","pornburst.xxx",
    "pornclassic.org","porncor.com","porndig.com","porndig.net","porndish.com",
    "pornditt.com","porndoe.com","porndroids.com","pornflick.com","pornfromrussia.com",
    "pornhat.com","pornhd.com","pornhd3x.com","pornheed.com","pornhits.com",
    "pornhoarder.tv","pornhub.com","pornhub.net","pornhub.org","pornhub.to",
    "pornjk.com","pornkite.com","pornktube.org","pornlib.org","pornmaki.com",
    "pornmd.com","pornochic.com","pornocomics.com","pornoempire.org","pornofan.com",
    "pornofilmpje.com","pornolab.net","pornone.com","pornorama.com","pornotop.com",
    "pornotorrent.net","pornovore.fr","pornoxxxfree.org","pornpics.com","pornpics.de",
    "pornrewind.com","pornstarsathome.com","porntrex.com","porntrex.net","pornvibe.org",
    "pornvost.com","pornwex.tv","pornxs.org","povr.com","private.com",
    "propellerads.com","public-pickups.com","publicdisgrace.com","pure-taboo.com","puremature.com",
    "pussyspace.com","pussyspace.org","r18.com","r34.app","realgfporn.com",
    "realgirlsgonebad.com","realitykings.com","realitykings.net","realpornfilms.com","redgifs.com",
    "redtube.com","redtube.net","redtube.org","retrojunk.org","retroporntube.org",
    "rule34.com","rule34.org","rule34.paheal.net","rule34.xxx","rutracker-porn.net",
    "safebooru.org","score-classic.com","scorevideos.com","sdc.com","seemomsuck.com",
    "sex-games.co","sex.com","sex.net","sex.xxx","sex3.com",
    "sexandsubmission.com","sexart.com","sexbroker.com","sexchatster.com","sexdome.com",
    "sexgratis.org","sexindubai.com","sexliberty.com","sexlikereal.com","sexlist.org",
    "sexmex.xxx","sexmoms.org","sexsearch.com","sexstation.tv","sextorrent.org",
    "sextpanther.com","sextube.com","sextube.net","sextube.org","sextube18.com",
    "sextvx.com","sextvx.org","sexu.org","sexvid.net","sexvid.pro",
    "sexvid.xxx","sexvideos.org","sexvideostube.org","sexyoldwomen.org","shagle.com",
    "shemale.xxx","shesfreaky.com","simply-hentai.com","sinful.com","skipthegames.com",
    "slixa.com","slutload.com","sluttyred.com","slutwife.com","snapsext.com",
    "spankbang.com","spankbang.party","spankingbang.com","spring-break-forever.com","stockingsvr.com",
    "streamate.com","stripchat.com","stripchat.net","stunning18.com","submissed.com",
    "suicidegirls.com","sunporno.com","sunporno.net","swapfinder.com","sweetheartvideo.com",
    "swingersdate.club","swingtowns.com","sxypix.com","tbib.org","team-skeet.com",
    "teamskeetselects.com","teenmegaworld.net","teenpornhub.com","teenporntube.org","teenslikeitbig.com",
    "teenxxxtube.org","tgirls.porn","theartofdesire.com","thelifeerotic.com","theporncollector.org",
    "theporndude.org","theyarehuge.com","thisvid.com","thothub.com","thothub.to",
    "thothub.tv","timstiletto.com","tiny4k.com","titsintops.com","tnaflix.com",
    "tnaflix.net","together2night.com","tokyomotion.net","traffichaus.com","trafficjunky.net",
    "trannytube.tv","transexual.xxx","tryst.link","tsyndicate.com","tube8.com",
    "tube8.org","tubegalore.com","tubepatrol.porn","tubestack.com","tukif.com",
    "tushy.com","twistys.com","txxx.com","txxx.net","udate.com",
    "videoxxxfr.org","vintagepornarchive.org","vivid.com","vixen.com","vporn.com",
    "vporn.net","vrallure.com","vrbangers.com","vrporn.com","wankitnow.com",
    "wankz.com","wankzvr.com","watch-my-gf.com","watch-xxx.com","watch4beauty.com",
    "watchmygf.com","watchmygf.me","watchmygf.net","watchmygf.org","watchporn.to",
    "webcamteens.org","wetvr.com","whengirlsplay.com","whippedass.com","wicked.com",
    "wildbuddies.com","wowgirls.com","x-art.com","xbabe.com","xbooru.com",
    "xcams.com","xdating.com","xhamster.com","xhamster.desi","xhamster.net",
    "xhamster.one","xhamster.org","xhamster2.com","xhamster3.com","xhamster43.com",
    "xhamsterlive.com","xhday.com","xhentai.org","xhtotal.com","xhwebsite.com",
    "xhwide1.com","xlovecam.com","xmatch.com","xmilf.com","xnxx.com",
    "xnxx.net","xnxx.org","xnxxcom.org","xozilla.com","xteencams.com",
    "xtube.com","xvideos.com","xvideos.es","xvideos.net","xvideos.org",
    "xvideos2.org","xxx.com","xxx.xxx","xxxbunker.com","yespornplease.com",
    "yespornplease.pro","yllix.com","youjizz.com","youporn.com","youporn.net",
    "zishy.com","zzseries.com",
}


def is_admin():
    try: return ctypes.windll.shell32.IsUserAnAdmin()
    except: return False

def build_entries():
    entries = set()
    for domain in BLOCKED_DOMAINS:
        entries.add(domain)
        for sub in SUBDOMAINS:
            entries.add(f"{sub}.{domain}")
    return sorted(entries)

def main():
    if not is_admin():
        print("Lance en Administrateur :")
        print("   Clic droit PowerShell -> Executer en tant qu'administrateur")
        sys.exit(1)

    entries = build_entries()
    print(f"Application du blocage complet : {len(BLOCKED_DOMAINS)} domaines -> {len(entries)} entrees (avec sous-domaines)")
    print()

    subprocess.run(["attrib", "-R", "-S", "-H", str(HOSTS_FILE)], capture_output=True)

    try:
        content = HOSTS_FILE.read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        print(f"Lecture hosts impossible: {e}")
        sys.exit(1)

    if HOSTS_MARKER in content and HOSTS_END in content:
        start = content.index(HOSTS_MARKER)
        end   = content.index(HOSTS_END) + len(HOSTS_END)
        content = content[:start].rstrip()
        print("Ancien bloc supprime.")

    lines = [f"\n\n{HOSTS_MARKER}"]
    for entry in entries:
        lines.append(f"0.0.0.0 {entry}")
    lines.append(f"{HOSTS_END}\n")
    block = "\n".join(lines)

    try:
        HOSTS_FILE.write_text(content + block, encoding="utf-8")
        print(f"{len(entries)} entrees ecrites dans le hosts file")
    except Exception as e:
        print(f"Ecriture impossible: {e}")
        sys.exit(1)

    subprocess.run(["attrib", "+R", "+S", str(HOSTS_FILE)], capture_output=True)

    try:
        for key_path in [
            r"SOFTWARE\Policies\Microsoft\Edge",
            r"SOFTWARE\Policies\Google\Chrome",
        ]:
            k = winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, key_path, 0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(k, "DnsOverHttpsMode",      0, winreg.REG_SZ, "off")
            winreg.SetValueEx(k, "DnsOverHttpsTemplates", 0, winreg.REG_SZ, "")
            winreg.CloseKey(k)
        print("DNS-over-HTTPS desactive dans Edge et Chrome")
    except Exception as e:
        print(f"DoH: {e}")

    subprocess.run(["ipconfig", "/flushdns"], capture_output=True)
    print("Cache DNS vide")

    check = HOSTS_FILE.read_text(encoding="utf-8", errors="ignore")
    print()
    if "xvideos.com" in check and "fr.xvideos.com" in check:
        print("SUCCES — domaines et sous-domaines bloques")

    print()
    print("Ferme completement Edge/Chrome (clic droit barre des taches -> Fermer)")
    print("puis rouvre et teste un site bloque.")

if __name__ == "__main__":
    main()
