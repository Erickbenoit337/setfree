# BlockGuard Windows v2

## ⚠️ Si l'ancienne version a cassé Internet

Lance d'abord la réparation :
```powershell
# PowerShell en Administrateur
python repair.py
```
Redémarre le PC. Internet sera rétabli.

---

## Pourquoi v2 fonctionne mieux

| | v1 (cassée) | v2 (corrigée) |
|---|---|---|
| Méthode | Modifiait le DNS du registre | Fichier hosts uniquement |
| Edge | ❌ Bypasse le DNS | ✅ Bloqué via hosts |
| Internet | ❌ Pouvait couper | ✅ Jamais coupé |
| DoH Edge/Chrome | ❌ Non géré | ✅ Désactivé via politique |

Le fichier hosts est lu par Windows **avant** toute requête réseau.
Tous les navigateurs le respectent — Edge, Chrome, Firefox, Opera, Brave.

---

## Installation v2

```powershell
# PowerShell en Administrateur
python install.py
```

## Vérification

```powershell
sc query WinNetDiagHost
# → STATE : 4 RUNNING = OK
```

Teste dans Edge : va sur un site bloqué → "Cette page est inaccessible"

## Désinstallation

```powershell
python repair.py
```
